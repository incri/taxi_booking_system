import os

current_dir = os.getcwd()
print(current_dir)


LOGO_LOCATION = os.getcwd() + "/img/logo.png"
BG_LOCATION = os.getcwd() + "/img/background.png"
ADMIN_LOGO_LOCATION = os.getcwd() + "/img/admin_logo.png"
DRIVER_LOGO_LOCATION = os.getcwd() + "/img/driver_logo.png"

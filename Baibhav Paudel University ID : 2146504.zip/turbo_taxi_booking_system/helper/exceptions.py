class CustomException(Exception):
    # raised when empty data
    pass

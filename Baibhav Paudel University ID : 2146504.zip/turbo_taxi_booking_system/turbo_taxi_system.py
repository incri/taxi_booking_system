from users.home import HomePage

HomePage()

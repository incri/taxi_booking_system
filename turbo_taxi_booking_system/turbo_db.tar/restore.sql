--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.6
-- Dumped by pg_dump version 14.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE turbo_db;
--
-- Name: turbo_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE turbo_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE turbo_db OWNER TO postgres;

\connect turbo_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin; Type: TABLE; Schema: public; Owner: incri
--

CREATE TABLE public.admin (
    username character varying(50),
    password character varying(50)
);


ALTER TABLE public.admin OWNER TO incri;

--
-- Name: booking; Type: TABLE; Schema: public; Owner: incri
--

CREATE TABLE public.booking (
    booking_id integer NOT NULL,
    user_id integer NOT NULL,
    firstname character varying(50) NOT NULL,
    lastname character varying(50) NOT NULL,
    no_of_passenger integer NOT NULL,
    no_of_taxi integer NOT NULL,
    pickup_date date NOT NULL,
    pickup_time_hrs integer NOT NULL,
    pickup_time_min integer NOT NULL,
    pickup_location character varying(100) NOT NULL,
    destination character varying(100) NOT NULL,
    total_cost character varying(20) NOT NULL,
    payment_method character varying(20) NOT NULL,
    card_number character varying(50),
    card_exp character varying(20),
    card_cvv character varying(10),
    booking_status character varying(20),
    created_at_date date NOT NULL,
    created_at_time character varying(30),
    pickup_coordinate character varying(100),
    destination_coordinate character varying(100),
    driver_id integer
);


ALTER TABLE public.booking OWNER TO incri;

--
-- Name: booking_booking_id_seq; Type: SEQUENCE; Schema: public; Owner: incri
--

CREATE SEQUENCE public.booking_booking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.booking_booking_id_seq OWNER TO incri;

--
-- Name: booking_booking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: incri
--

ALTER SEQUENCE public.booking_booking_id_seq OWNED BY public.booking.booking_id;


--
-- Name: drivers; Type: TABLE; Schema: public; Owner: incri
--

CREATE TABLE public.drivers (
    driverid integer NOT NULL,
    fullname character varying(50) NOT NULL,
    license_number character varying(50) NOT NULL,
    contact character varying(20) NOT NULL,
    taxi_number character varying(50) NOT NULL,
    driver_status character varying(50) NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(50) NOT NULL
);


ALTER TABLE public.drivers OWNER TO incri;

--
-- Name: drivers_driverid_seq; Type: SEQUENCE; Schema: public; Owner: incri
--

CREATE SEQUENCE public.drivers_driverid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.drivers_driverid_seq OWNER TO incri;

--
-- Name: drivers_driverid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: incri
--

ALTER SEQUENCE public.drivers_driverid_seq OWNED BY public.drivers.driverid;


--
-- Name: taxi; Type: TABLE; Schema: public; Owner: incri
--

CREATE TABLE public.taxi (
    taxiid integer NOT NULL,
    brand character varying(50) NOT NULL,
    model character varying(50) NOT NULL,
    taxi_number character varying(20) NOT NULL,
    taxi_age integer NOT NULL,
    discription character varying(50) NOT NULL,
    status character varying(40)
);


ALTER TABLE public.taxi OWNER TO incri;

--
-- Name: taxi_taxiid_seq; Type: SEQUENCE; Schema: public; Owner: incri
--

CREATE SEQUENCE public.taxi_taxiid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.taxi_taxiid_seq OWNER TO incri;

--
-- Name: taxi_taxiid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: incri
--

ALTER SEQUENCE public.taxi_taxiid_seq OWNED BY public.taxi.taxiid;


--
-- Name: users; Type: TABLE; Schema: public; Owner: incri
--

CREATE TABLE public.users (
    userid integer NOT NULL,
    firstname character varying(50) NOT NULL,
    lastname character varying(50) NOT NULL,
    contact character varying(20) NOT NULL,
    address character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    username character varying(20) NOT NULL,
    password character varying(20) NOT NULL,
    profile bytea
);


ALTER TABLE public.users OWNER TO incri;

--
-- Name: users_userid_seq; Type: SEQUENCE; Schema: public; Owner: incri
--

CREATE SEQUENCE public.users_userid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_userid_seq OWNER TO incri;

--
-- Name: users_userid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: incri
--

ALTER SEQUENCE public.users_userid_seq OWNED BY public.users.userid;


--
-- Name: booking booking_id; Type: DEFAULT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.booking ALTER COLUMN booking_id SET DEFAULT nextval('public.booking_booking_id_seq'::regclass);


--
-- Name: drivers driverid; Type: DEFAULT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.drivers ALTER COLUMN driverid SET DEFAULT nextval('public.drivers_driverid_seq'::regclass);


--
-- Name: taxi taxiid; Type: DEFAULT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.taxi ALTER COLUMN taxiid SET DEFAULT nextval('public.taxi_taxiid_seq'::regclass);


--
-- Name: users userid; Type: DEFAULT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.users ALTER COLUMN userid SET DEFAULT nextval('public.users_userid_seq'::regclass);


--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: incri
--

COPY public.admin (username, password) FROM stdin;
\.
COPY public.admin (username, password) FROM '$$PATH$$/3361.dat';

--
-- Data for Name: booking; Type: TABLE DATA; Schema: public; Owner: incri
--

COPY public.booking (booking_id, user_id, firstname, lastname, no_of_passenger, no_of_taxi, pickup_date, pickup_time_hrs, pickup_time_min, pickup_location, destination, total_cost, payment_method, card_number, card_exp, card_cvv, booking_status, created_at_date, created_at_time, pickup_coordinate, destination_coordinate, driver_id) FROM stdin;
\.
COPY public.booking (booking_id, user_id, firstname, lastname, no_of_passenger, no_of_taxi, pickup_date, pickup_time_hrs, pickup_time_min, pickup_location, destination, total_cost, payment_method, card_number, card_exp, card_cvv, booking_status, created_at_date, created_at_time, pickup_coordinate, destination_coordinate, driver_id) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: incri
--

COPY public.drivers (driverid, fullname, license_number, contact, taxi_number, driver_status, username, password) FROM stdin;
\.
COPY public.drivers (driverid, fullname, license_number, contact, taxi_number, driver_status, username, password) FROM '$$PATH$$/3369.dat';

--
-- Data for Name: taxi; Type: TABLE DATA; Schema: public; Owner: incri
--

COPY public.taxi (taxiid, brand, model, taxi_number, taxi_age, discription, status) FROM stdin;
\.
COPY public.taxi (taxiid, brand, model, taxi_number, taxi_age, discription, status) FROM '$$PATH$$/3367.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: incri
--

COPY public.users (userid, firstname, lastname, contact, address, email, username, password, profile) FROM stdin;
\.
COPY public.users (userid, firstname, lastname, contact, address, email, username, password, profile) FROM '$$PATH$$/3363.dat';

--
-- Name: booking_booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: incri
--

SELECT pg_catalog.setval('public.booking_booking_id_seq', 3, true);


--
-- Name: drivers_driverid_seq; Type: SEQUENCE SET; Schema: public; Owner: incri
--

SELECT pg_catalog.setval('public.drivers_driverid_seq', 2, true);


--
-- Name: taxi_taxiid_seq; Type: SEQUENCE SET; Schema: public; Owner: incri
--

SELECT pg_catalog.setval('public.taxi_taxiid_seq', 2, true);


--
-- Name: users_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: incri
--

SELECT pg_catalog.setval('public.users_userid_seq', 7, true);


--
-- Name: booking booking_pkey; Type: CONSTRAINT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT booking_pkey PRIMARY KEY (booking_id);


--
-- Name: drivers drivers_license_number_key; Type: CONSTRAINT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_license_number_key UNIQUE (license_number);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (driverid);


--
-- Name: drivers drivers_username_key; Type: CONSTRAINT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_username_key UNIQUE (username);


--
-- Name: taxi taxi_pkey; Type: CONSTRAINT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.taxi
    ADD CONSTRAINT taxi_pkey PRIMARY KEY (taxiid);


--
-- Name: taxi taxi_taxi_number_key; Type: CONSTRAINT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.taxi
    ADD CONSTRAINT taxi_taxi_number_key UNIQUE (taxi_number);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (userid);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: incri
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: DATABASE turbo_db; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE turbo_db TO incri;


--
-- PostgreSQL database dump complete
--

